package com.rest_microservice.rest_microservice.service;

import com.rest_microservice.rest_microservice.dto.UserResponseDTO;
import com.rest_microservice.rest_microservice.model.User;
import com.rest_microservice.rest_microservice.repository.UserRepository;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    private final UserRepository userRepository;
    private final BCryptPasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepository){
        this.userRepository=userRepository;
        this.passwordEncoder=new BCryptPasswordEncoder();
    }
    public User registerUser(User user){
        String hashPassword=passwordEncoder.encode(user.getPassword());
        user.setPassword(hashPassword);
        return userRepository.save(user);
    }

    public UserResponseDTO loginUser(String name, String rawPassword){
        User user=userRepository.findByName(name).orElseThrow(()->new RuntimeException("User not found"));
        if(!passwordEncoder.matches(rawPassword, user.getPassword())){
            throw new RuntimeException("Invalid credentials");
        }
        UserResponseDTO userInfo=new UserResponseDTO();
        userInfo.setId(user.getId());
        userInfo.setName(user.getName());
        userInfo.setEmail(user.getEmail());
        return userInfo;
    }
}
