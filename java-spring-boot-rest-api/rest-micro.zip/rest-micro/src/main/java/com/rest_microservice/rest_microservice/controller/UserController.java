package com.rest_microservice.rest_microservice.controller;

import com.rest_microservice.rest_microservice.dto.LoginRequestDTO;
import com.rest_microservice.rest_microservice.dto.UserResponseDTO;
import com.rest_microservice.rest_microservice.model.User;
import com.rest_microservice.rest_microservice.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.lang.reflect.Method;

@RestController
@RequestMapping("/user")
public class UserController {
    private final UserService userService;
    public UserController(UserService userService){
        this.userService=userService;
    }
    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody User user) {
        User registerUser = userService.registerUser(user);
        return ResponseEntity.ok("user registered successfully");
    }

    @PostMapping("/login")
    public ResponseEntity<UserResponseDTO> login(@RequestBody LoginRequestDTO loginRequestDTO){
        UserResponseDTO  userResponseDTO=userService.loginUser(loginRequestDTO.getName(), loginRequestDTO.getPassword());
        return ResponseEntity.ok(userResponseDTO);
    }
}
