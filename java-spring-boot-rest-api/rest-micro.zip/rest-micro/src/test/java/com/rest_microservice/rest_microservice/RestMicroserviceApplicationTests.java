package com.rest_microservice.rest_microservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
